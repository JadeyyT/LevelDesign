﻿namespace Gley.Common
{
    public class Constants
    {

        //Mobile Ads
        public const string USE_ADCOLONY = "USE_ADCOLONY";
        public const string USE_ADMOB = "USE_ADMOB;USE_ADMOB_PATCH";
        public const string USE_ADMOB_PATCH = "USE_ADMOB_PATCH";
        public const string USE_CHARTBOOST = "USE_CHARTBOOST";
        public const string USE_HEYZAP = "USE_HEYZAP";
        public const string USE_UNITYADS = "USE_UNITYADS";
        public const string USE_VUNGLE = "USE_VUNGLE";
        public const string USE_APPLOVIN = "USE_APPLOVIN";
        public const string USE_FACEBOOKADS = "USE_FACEBOOKADS";
        public const string USE_MOPUB = "USE_MOPUB";
        public const string USE_IRONSOURCE = "USE_IRONSOURCE";

        //Visual Scripting
        public const string USE_PLAYMAKER_SUPPORT = "USE_PLAYMAKER_SUPPORT";
        public const string USE_BOLT_SUPPORT = "USE_BOLT_SUPPORT";
        public const string USE_GAMEFLOW_SUPPORT = "USE_GAMEFLOW_SUPPORT";

        //Traffic
        public const string USE_GLEY_TRAFFIC = "USE_GLEY_TRAFFIC";
        public const string DEBUG_TRAFFIC = "DEBUG_TRAFFIC";
    }
}
