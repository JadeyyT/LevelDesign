﻿namespace Gley.About
{
    public enum AssetState
    {
        InProject,
        UpdateAvailable,
        ComingSoon,
        NotDownloaded
    }
}
